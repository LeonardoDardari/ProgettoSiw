package com.example.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.validation.Valid;
import com.example.demo.controller.session.SessionData;
import com.example.demo.controller.validation.CredentialValidator;
import com.example.demo.controller.validation.UserValidator;
import com.example.demo.model.Credential;
import com.example.demo.model.User;
import com.example.demo.services.CredentialService;


@Controller
public class AuthenticationController {

    @Autowired
    CredentialService credentialsService;

    @Autowired
    UserValidator userValidator;

    @Autowired
    CredentialValidator credentialsValidator;

    @Autowired
    SessionData sessionData;


    @RequestMapping(value = { "/users/register" }, method = RequestMethod.GET)
    public String showRegisterForm(Model model) {
        model.addAttribute("userForm", new User());
        model.addAttribute("credentialsForm", new Credential());

        return "registerUser";
    }

   
    @RequestMapping(value = { "/users/register" }, method = RequestMethod.POST)
    public String registerUser(@Valid @ModelAttribute("userForm") User user,
                               BindingResult userBindingResult,
                               @Valid @ModelAttribute("credentialsForm") Credential credentials,
                               BindingResult credentialsBindingResult,
                               Model model) {

        
        this.userValidator.validate(user, userBindingResult);
        this.credentialsValidator.validate(credentials, credentialsBindingResult);

       
        if(!userBindingResult.hasErrors() && ! credentialsBindingResult.hasErrors()) {
            
            credentials.setUser(user);
            credentialsService.saveCredential(credentials);
            return "registrationSuccessful";
        }
        return "registerUser";
    }
}
