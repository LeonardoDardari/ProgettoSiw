package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.controller.session.SessionData;
import com.example.demo.controller.validation.ProjectValidator;
import com.example.demo.model.Credential;
import com.example.demo.model.Project;
import com.example.demo.model.Task;
import com.example.demo.model.User;
import com.example.demo.repository.CredentialRepository;
import com.example.demo.repository.TaskRepository;
import com.example.demo.services.CredentialService;
import com.example.demo.services.ProjectService;
import com.example.demo.services.TaskService;
import com.example.demo.services.UserService;

@Controller
public class ProjectController {

	@Autowired
	CredentialService credentialService;
	
	@Autowired
	TaskService taskService;
	
	@Autowired
	ProjectService projectService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	ProjectValidator projectValidator;
	
	@Autowired
	SessionData sessionData;
	
	@RequestMapping(value= {"/projects"},method=RequestMethod.GET)
	public String myOwnedProjects(Model model) {
		User loggedUser=sessionData.getLoggedUser();
		List<Project>projectsList=projectService.retrieveProjectsOwnedBy(loggedUser);
		model.addAttribute("loggedUser",loggedUser);
		model.addAttribute("projectsList",projectsList);
		
		return "myOwnedProjects";
				
		}
	
	@RequestMapping(value= {"/visibleProjects"},method=RequestMethod.GET)
	public String VisibleProjects(Model model) {
		User loggedUser=sessionData.getLoggedUser();
		List<Project>projectsList=projectService.retrieveVisibleProjects(loggedUser);
		model.addAttribute("loggedUser",loggedUser);
		model.addAttribute("projectsList",projectsList);
		
		return "visibleProjects";
				
		}
	
	@RequestMapping(value= {"/projects/{projectId}"},method=RequestMethod.GET)
	public String project(Model model,
						  @PathVariable Long projectId) {
		
		User loggedUser=sessionData.getLoggedUser();
		Project project=projectService.getProject(projectId);
		if(project==null)
			return "redirect:/projects";
		
		List<User> members=userService.getMembers(project);
		if(!project.getOwner().equals(loggedUser)&& !members.contains(loggedUser))
			return "redirect:/projects";
		
		model.addAttribute("loggedUser",loggedUser);
		model.addAttribute("project",project);
		model.addAttribute("members",members);
		return "project";
	}
	
	
	@RequestMapping(value= {"/projects/add"}, method=RequestMethod.GET)
	public String createProjectB(Model model) {
		User loggedUser=sessionData.getLoggedUser();
		model.addAttribute("loggedUser",loggedUser);
		model.addAttribute("projectForm",new Project());
		return  "projectsAdd";
		
		
	}
	
	@RequestMapping(value= {"/projects/add"}, method=RequestMethod.POST)
	public String createProject(@Valid @ModelAttribute("projectForm")Project project,
								BindingResult projectBindingResult,
								Model model) {
		
		User loggedUser=sessionData.getLoggedUser();
		
		projectValidator.validate(project,projectBindingResult);
		if(!projectBindingResult.hasErrors()) {
			project.setOwner(loggedUser);
			this.projectService.saveProject(project);
			return "redirect:/projects/" + project.getId();
		}
		
		model.addAttribute("loggedUser",loggedUser);
		return "projectsAdd";
		
		
	}
	
	@RequestMapping(value= {"/sharedwith/{projectId}"},method=RequestMethod.GET)
	public String sharedWithPost(Model model,
			  @PathVariable Long projectId) {
		
		String username=new String();
		User loggedUser=sessionData.getLoggedUser();
		Project project=projectService.getProject(projectId);
		if(project==null)
			return "redirect:/projects";
		
		
		model.addAttribute("username",username);
		model.addAttribute("loggedUser",loggedUser);
		model.addAttribute("project",project);
		
		return "sharedWith";
	}
	
	
	@RequestMapping(value= {"/sharedwith/{projectId}"},method=RequestMethod.POST)
	public String sharedWith( @ModelAttribute("username")String username,@PathVariable Long projectId,
			Model model) {
		
		User loggedUser=sessionData.getLoggedUser();
		
		
		Project project=projectService.getProject(projectId);
		
		Credential credential=this.credentialService.getCredential(username);
		
		if(credential!=null && !(project.getOwner().getUsername().equals(username))) {
			this.projectService.shareProjectWithUser(project, credential.getUser());
			return "redirect:/projects/";
		}
		
		
		
	
		model.addAttribute("project",project);
		model.addAttribute("username",username);
		model.addAttribute("loggedUser",loggedUser);
		
		return "sharedWith";
	}
	
	 @RequestMapping(value= {"/delete/{projectId}"},method=RequestMethod.POST)
	    public String removeProject(Model model,@PathVariable Long projectId) {
	    	
		 Project project=projectService.getProject(projectId);
		 
		 	this.projectService.deleteProject(project);
		 	
		 	model.addAttribute("projectsList",this.projectService.retrieveProjectsOwnedBy(sessionData.getLoggedUser()));
	    	return "myOwnedProjects";
	    }
	 
	 @RequestMapping(value= {"/editName/{projectId}"}, method=RequestMethod.GET)
		public String editProjectName(Model model,@PathVariable Long projectId) {
		 
		 Project project=this.projectService.getProject(projectId);
		 
		 model.addAttribute("project",project);
		 
		 return "editName";
	 }
	 
	 @RequestMapping(value= {"/editName/{projectId}"}, method=RequestMethod.POST)
		public String editProjectNamePost(Model model,@PathVariable Long projectId,
											@ModelAttribute("nuovoNome")String nome) {
	 
		 Project project=this.projectService.getProject(projectId);
		 
		 if(nome.isEmpty()) {
			 model.addAttribute("project",project);
			 
			 return "redirect:/editName/{projectId}";
			 
		 }
		 
		 project.setName(nome);
		 
		 this.projectService.saveProject(project);
		 
		 model.addAttribute("projectsList",this.projectService.retrieveProjectsOwnedBy(sessionData.getLoggedUser()));
		 
		 return "myOwnedProjects";
		 
		}
	 
	 
	 @RequestMapping(value= {"/editDescription/{projectId}"}, method=RequestMethod.GET)
		public String editProjectDescription(Model model,@PathVariable Long projectId) {
		 
		 Project project=this.projectService.getProject(projectId);
		 
		 model.addAttribute("project",project);
		 
		 return "editDescription";
	 }
	 
	 @RequestMapping(value= {"/editDescription/{projectId}"}, method=RequestMethod.POST)
		public String editProjectDescriptionPost(Model model,@PathVariable Long projectId,
											@ModelAttribute("nuovaDescrizione")String descrizione) {
	 
		 Project project=this.projectService.getProject(projectId);
		 
		 project.setDescription(descrizione);
		 
		 this.projectService.saveProject(project);
		 
		 model.addAttribute("projectsList",this.projectService.retrieveProjectsOwnedBy(sessionData.getLoggedUser()));
		 
		 return "myOwnedProjects";
		 
		}
	 
	 
	 @RequestMapping(value= {"/elenco/{projectId}"},method=RequestMethod.GET)
		public String elencoTask(Model model,
				  @PathVariable Long projectId) {
		 
		 Project project = this.projectService.getProject(projectId);
		 
		 model.addAttribute("project",project);
		 
		 return "tasks";
		 
		 
		 
	 }
	 
	 
	 
	 
	 @RequestMapping(value= {"/assegna/{taskId}/{projectId}"},method=RequestMethod.GET)
		public String assegnaTask(Model model,@PathVariable Long taskId,
				  @PathVariable Long projectId) {
			
			
			User loggedUser=sessionData.getLoggedUser();
			Project project = this.projectService.getProject(projectId);
			Task task=this.taskService.getTask(taskId);
			
			
			List<User>members=this.userService.getMembers(project);
			
			
			
			model.addAttribute("userMemberList",members);
			
			model.addAttribute("project",project);
			
			model.addAttribute("task",task);
			
			return "assegnaTask";
		}
}
