package com.example.demo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.controller.session.SessionData;
import com.example.demo.model.Project;
import com.example.demo.model.Task;
import com.example.demo.model.User;
import com.example.demo.repository.TaskRepository;
import com.example.demo.services.ProjectService;
import com.example.demo.services.TaskService;
import com.example.demo.services.UserService;

@Controller
public class TaskController {

	
	@Autowired
	SessionData sessionData;
	
	@Autowired
	private TaskRepository taskRepository;
	
	@Autowired
	private  TaskService taskService;
	@Autowired
	private ProjectService projectService;
	
	@Autowired
	UserService userService;
	
	
	@RequestMapping(value= {"/addTask/{projectId}"}, method=RequestMethod.GET)
	public String createProjectB(Model model,@PathVariable Long projectId) {
	
		Project project=this.projectService.getProject(projectId);
		
		model.addAttribute("project",project);
		
		model.addAttribute("taskForm",new Task());
		
		return  "addTask";
		
		
	}
	
	@RequestMapping(value= {"/addTask/{projectId}"}, method=RequestMethod.POST)
	public String createProject(@ModelAttribute("taskForm")Task task,
								Model model,@ModelAttribute("nameTask")String name,
								@ModelAttribute("descriptionTask")String descrizione,
								@PathVariable Long projectId) {
		
		Project project=this.projectService.getProject(projectId);
		
		
		if(name.isEmpty()){
			model.addAttribute("project",project);
			
			model.addAttribute("taskForm",new Task());
			
			return "redirect:/addTask/{projectId}";
		}
		
		task.setName(name);
		task.setDescription(descrizione);
		
		
		this.projectService.saveTask(task,project);
		
		
		model.addAttribute("user",sessionData.getLoggedUser());
		
		return "home";
		
		
	}
	
	@RequestMapping(value= {"/checkbox/{taskId}"}, method=RequestMethod.POST)
	public String CheckBox(@PathVariable Long taskId,
								Model model) {
			Task task=this.taskService.getTask(taskId);
			task.setCompleted(true);
			this.taskService.saveTask(task);
			model.addAttribute("user",sessionData.getLoggedUser());
			
			return "home";
	
}
	
	@RequestMapping(value= {"/checkboxDue/{taskId}"}, method=RequestMethod.POST)
	public String CheckBoxDue(@PathVariable Long taskId,
								Model model) {
			Task task=this.taskService.getTask(taskId);
			task.setCompleted(false);
			this.taskService.saveTask(task);
			model.addAttribute("user",sessionData.getLoggedUser());
			
			return "home";
	
}
	
	@RequestMapping(value= {"/deleteTask/{taskId}"},method=RequestMethod.POST)
    public String removeProject(Model model,@PathVariable Long taskId) {
    	
	 Task task=this.taskService.getTask(taskId);
	 
	 	this.taskService.deleteTask(task);
	 	
	 	model.addAttribute("projectsList",this.projectService.retrieveProjectsOwnedBy(sessionData.getLoggedUser()));
    	return "myOwnedProjects";
    }
	
	
	 @RequestMapping(value= {"/editNomeT/{taskId}"}, method=RequestMethod.GET)
		public String editProjectName(Model model,@PathVariable Long taskId) {
		 
		 Task task=this.taskService.getTask(taskId);
		 
		
		 
		 model.addAttribute("task",task);
		 
		 return "editNameT";
	 }
	
	
	
	@RequestMapping(value= {"/editNomeT/{taskId}"}, method=RequestMethod.POST)
	public String editProjectNamePost(Model model,@PathVariable Long taskId,
										@ModelAttribute("nuovoNome")String nome) {
 
	 Task task=this.taskService.getTask(taskId);
	 
	 if(nome.isEmpty()) {
		 
		 model.addAttribute("task",task);
		 return "redirect:/editNomeT/{taskId}";
	 }
	 
	 task.setName(nome);
	 
	 this.taskService.saveTask(task);
	 
	 model.addAttribute("projectsList",this.projectService.retrieveProjectsOwnedBy(sessionData.getLoggedUser()));
	 
	 return "myOwnedProjects";
	 
	}
	
	
	@RequestMapping(value= {"/editDescriptionT/{taskId}"}, method=RequestMethod.GET)
	public String editProjectDescription(Model model,@PathVariable Long taskId) {
	 
	 Task task=this.taskService.getTask(taskId);
	 
	 model.addAttribute("task",task);
	 
	 return "editDescriptionT";
 }
 
 @RequestMapping(value= {"/editDescriptionT/{taskId}"}, method=RequestMethod.POST)
	public String editProjectDescriptionPost(Model model,@PathVariable Long taskId,
										@ModelAttribute("nuovaDescrizione")String descrizione) {
 
	 Task task=this.taskService.getTask(taskId);
	 
	 task.setDescription(descrizione);
	 
	 this.taskService.saveTask(task);
	 
	 model.addAttribute("projectsList",this.projectService.retrieveProjectsOwnedBy(sessionData.getLoggedUser()));
	 
	 return "myOwnedProjects";
	 
	}
 
 @RequestMapping(value= {"/assegnaTask/{taskId}/{projectId}/{userMemberId}"},method=RequestMethod.POST)
 public String ViewTask(Model model,@PathVariable Long taskId,@PathVariable Long projectId,@PathVariable Long userMemberId) {
 	
	 Task task=this.taskService.getTask(taskId);
	 User user=this.userService.getUser(userMemberId);
	 Project project=this.projectService.getProject(projectId);
	
	
	 
	 task.setUserTask(user);
	 
	 this.taskService.saveUser(user, task);
	
	 
	 	
	 //model.addAttribute("user",sessionData.getLoggedUser());
 	
	 model.addAttribute("project",project);	
	 
 	return "tasks";
 }
 
 
	
	
	
	
}
