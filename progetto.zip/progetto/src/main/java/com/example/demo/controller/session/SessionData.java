package com.example.demo.controller.session;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.example.demo.model.Credential;
import com.example.demo.model.User;
import com.example.demo.repository.CredentialRepository;




@Component
@Scope(value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SessionData {

  
    private User user;

  
    private Credential credentials;

    @Autowired
    private CredentialRepository credentialsRepository;

  
    public Credential getLoggedCredentials() {
        if (this.credentials == null)
        	//cerca nel db
            this.update();
        return this.credentials;
    }

 
    public User getLoggedUser() {
        if (this.user == null)
        	//cerca nel db
            this.update();
        return this.user;
    }

    
    private void update() {
        UserDetails loggedUserDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        this.credentials = this.credentialsRepository.findByUsername(loggedUserDetails.getUsername()).get(); 
        this.credentials.setPassword("[PROTECTED]");
        this.user = this.credentials.getUser();
    }
}