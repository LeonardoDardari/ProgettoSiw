package com.example.demo.model;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Tag {

	@Id
	@GeneratedValue (strategy=GenerationType.AUTO)
	
	private Long id;
	
	@Column(nullable=false,length=100)
	private String nome;
	
	@Column(nullable=false,length=100)
	private String colore;
	
	@Column(nullable=false,length=100)
	private String descrizione;
	
	
	
	
	@ManyToMany
	private List<Task> tasks;
	
	
	
	
	
	public Tag() {
		this.tasks=new ArrayList<>();
	}





	public Long getId() {
		return id;
	}





	public void setId(Long id) {
		this.id = id;
	}





	public String getNome() {
		return nome;
	}





	public void setNome(String nome) {
		this.nome = nome;
	}





	public String getColore() {
		return colore;
	}





	public void setColore(String colore) {
		this.colore = colore;
	}





	public String getDescrizione() {
		return descrizione;
	}





	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}





	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((colore == null) ? 0 : colore.hashCode());
		result = prime * result + ((descrizione == null) ? 0 : descrizione.hashCode());
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		return result;
	}





	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Tag other = (Tag) obj;
		if (colore == null) {
			if (other.colore != null)
				return false;
		} else if (!colore.equals(other.colore))
			return false;
		if (descrizione == null) {
			if (other.descrizione != null)
				return false;
		} else if (!descrizione.equals(other.descrizione))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		return true;
	}
	
	
	
}
