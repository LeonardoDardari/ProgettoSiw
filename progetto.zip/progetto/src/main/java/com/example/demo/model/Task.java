package com.example.demo.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

@Entity
public class Task {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)

	private Long id;
	
	@Column(unique=true,nullable=false,length=100)
	private String name;
	
	@Column(unique=true,nullable=false,length=100)
	private String description;
	
	@Column(nullable=false)
	private boolean completed;
	
	
	@Column(nullable=false,updatable=false)
	private LocalDateTime creationTimeStamp;

	@Column(nullable=false)
	private LocalDateTime lastUpdateTimestamp;

	@ManyToMany(mappedBy="tasks")
	private List<Tag>tags;
	
	@ManyToOne
	private User userTask;
	
	
	public Task() {
		this.tags=new ArrayList<>();
	}
	
	
	
	public Task(String name,String description,boolean completed) {
		this();
		this.name=name;
		this.description=description;
		this.completed=completed;
		
	}
	
	@PrePersist
	protected void pippo() {
		this.creationTimeStamp=LocalDateTime.now();
		this.lastUpdateTimestamp=LocalDateTime.now();
	}
	
	@PreUpdate
	protected void paperino() {
		this.lastUpdateTimestamp=LocalDateTime.now();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//GETTER AND SETTER
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isCompleted() {
		return completed;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

	public LocalDateTime getCreationTimeStamp() {
		return creationTimeStamp;
	}

	public void setCreationTimeStamp(LocalDateTime creationTimeStamp) {
		this.creationTimeStamp = creationTimeStamp;
	}

	public LocalDateTime getLastUpdateTimestamp() {
		return lastUpdateTimestamp;
	}

	public void setLastUpdateTimestamp(LocalDateTime lastUpdateTimestamp) {
		this.lastUpdateTimestamp = lastUpdateTimestamp;
	}



	public User getUserTask() {
		return userTask;
	}



	public void setUserTask(User userTask) {
		this.userTask = userTask;
	}
	
	
	
	

	
	
	
}
