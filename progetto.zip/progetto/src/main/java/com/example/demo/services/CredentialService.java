package com.example.demo.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Credential;
import com.example.demo.model.User;
import com.example.demo.repository.CredentialRepository;

@Service
public class CredentialService {

	@Autowired
	protected PasswordEncoder passwordEncoder;
	
	@Autowired 
	private CredentialRepository credentialRepository;
	
	@Transactional
	public Credential getCredential(Long id) {
		Optional<Credential> result=this.credentialRepository.findById(id);
		return result.orElse(null);
		
	}
	
	@Transactional
	public Credential getCredential(String username) {
		Optional<Credential> result=this.credentialRepository.findByUsername(username);
		return result.orElse(null);
		
	}
	
	//questo metodo salva le credenziali nel db e prima di salvarle setta il ruolo di default.
	@Transactional
	public Credential saveCredential(Credential credential) {
		credential.setRole(Credential.DEFAULT_ROLE);
		credential.setPassword(this.passwordEncoder.encode(credential.getPassword()));
		return this.credentialRepository.save(credential);
		
		
	}
	
	@Transactional
	public List<Credential> getAll() {
		Iterable<Credential> i=this.credentialRepository.findAll();
		List<Credential> lista=new ArrayList<>();
		for(Credential c:i) {
			lista.add(c);
		}
		return lista;
		
	}

	public void deleteCredentials(String username) {
		Optional<Credential> credentials=this.credentialRepository.findByUsername(username);
		this.credentialRepository.delete(credentials.get());
	}
	
	
	
	
}
